from visualization import draw_multiple_histogram, draw_multiple_boxplot
from crawl_data import crawl_data
from visualization import draw_question_five

majors = ['Công nghệ thông tin', 'Thời trang', 'Cơ khí', 'Kế toán', 'Xây dựng', 'Du lịch', 'Giáo dục', 'Nhân sự', 'Báo chí', 'Bất động sản']
# majors = ['Công nghệ thông tin']

if __name__ == '__main__':
    crawl_data()
    draw_multiple_boxplot(majors)
    draw_multiple_histogram(majors)
    draw_question_five()
